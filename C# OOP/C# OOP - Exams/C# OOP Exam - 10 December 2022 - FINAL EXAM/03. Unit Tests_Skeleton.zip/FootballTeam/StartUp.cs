﻿namespace FootballTeam
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
