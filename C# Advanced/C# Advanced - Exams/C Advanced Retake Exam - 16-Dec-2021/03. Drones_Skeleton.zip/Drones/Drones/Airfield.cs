﻿namespace Drones
{
    public class Airfield
    {
    }
}
