﻿namespace Drones
{
    public class Drone
    {
    }
}
